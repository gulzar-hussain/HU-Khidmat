
-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '0'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '319'),
(18, 1, 'wp_user-settings', 'libraryContent=browse&editor=tinymce'),
(19, 1, 'wp_user-settings-time', '1661767337'),
(21, 1, 'dismiss_bosa_upsell_notice', '1'),
(22, 1, 'wpcf7_hide_welcome_panel_on', 'a:1:{i:0;s:3:\"5.5\";}'),
(23, 1, 'meta-box-order_lgx_counter', 'a:3:{s:4:\"side\";s:39:\"submitdiv,lgxcountercatdiv,postimagediv\";s:6:\"normal\";s:25:\"slugdiv,metabox_milestone\";s:8:\"advanced\";s:0:\"\";}'),
(24, 1, 'screen_layout_lgx_counter', '2'),
(25, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(26, 1, 'metaboxhidden_nav-menus', 'a:5:{i:0;s:28:\"add-post-type-e-landing-page\";i:1;s:25:\"add-post-type-lgx_counter\";i:2;s:12:\"add-post_tag\";i:3;s:15:\"add-post_format\";i:4;s:17:\"add-lgxcountercat\";}'),
(27, 1, 'nav_menu_recently_edited', '4'),
(28, 1, 'session_tokens', 'a:1:{s:64:\"7581699850f6fb40e7d7c69e903d04b600f983e9f52b360c1dd6f5054cd09ade\";a:4:{s:10:\"expiration\";i:1661940140;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:80:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:103.0) Gecko/20100101 Firefox/103.0\";s:5:\"login\";i:1661767340;}}'),
(29, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}');
