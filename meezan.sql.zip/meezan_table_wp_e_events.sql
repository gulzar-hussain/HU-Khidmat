
-- --------------------------------------------------------

--
-- Table structure for table `wp_e_events`
--

CREATE TABLE `wp_e_events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `event_data` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
